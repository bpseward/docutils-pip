This is the directory where the actual output is stored.

This README.txt is just a placeholder to make CVS create the directory.
